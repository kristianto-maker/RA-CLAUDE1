'use client';
import React from "react";

export default function SciMapApp() {
  return (
    <div style={{padding:"40px", textAlign:"center"}}>
      <h1>SciMap Polsub ✅</h1>
      <p>Aplikasi siap deploy di Astro + React</p>
      <p>Silakan replace file ini dengan sistem Anda.</p>
    </div>
  );
}
